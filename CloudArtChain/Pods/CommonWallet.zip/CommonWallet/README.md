# CommonWallet

[![CI Status](https://img.shields.io/travis/ERussel/CommonWallet.svg?style=flat)](https://travis-ci.org/ERussel/CommonWallet)
[![Version](https://img.shields.io/cocoapods/v/CommonWallet.svg?style=flat)](https://cocoapods.org/pods/CommonWallet)
[![License](https://img.shields.io/cocoapods/l/CommonWallet.svg?style=flat)](https://cocoapods.org/pods/CommonWallet)
[![Platform](https://img.shields.io/cocoapods/p/CommonWallet.svg?style=flat)](https://cocoapods.org/pods/CommonWallet)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

CommonWallet is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'CommonWallet'
```

## Author

ERussel, rezin@soramitsu.co.jp

## License

CommonWallet is available under the GPL 3.0 license. See the LICENSE file for more info.
